export default (x, y, r) => {
  return x + ((y - x) * r)
}
